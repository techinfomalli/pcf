package com.gaig.microservices.zuulapigatewayserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulApigatewayServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
