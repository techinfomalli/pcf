package com.exstreamproxyservice.exstreamproxyservice.controllers;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.exstreamproxyservice.exstreamproxyservice.configs.RabbitMQSender;
import com.exstreamproxyservice.exstreamproxyservice.models.Document;
import com.exstreamproxyservice.exstreamproxyservice.models.DocumentDCS;

@RestController
public class ExstreamProxyServiceController {
	
	
	
	@Value("${exstreamUri}")
	String uri;
	
	//final String uri = "http://13.90.36.249:8091/EmpowerService/generateEmpowerDocument";

	@Autowired
	private AmqpTemplate amqpTemplate;
	@Autowired
	RabbitMQSender rabbitMQSender;
	
	
		
	@RequestMapping(value="/exstreampush",method=RequestMethod.POST)
	public String empowerpush(@RequestBody DocumentDCS documentdcs) {
		System.out.println(documentdcs.concatvalues());
		Document document = new Document(documentdcs.getclaimNumber(),documentdcs.concatvalues());
		RestTemplate restTemplate = new RestTemplate();
		try {
					return restTemplate.postForObject(uri, document, String.class);
			
		} catch (Exception e) {
			System.out.println(e);
			return e.toString();
		}
			
	}
	
	
	

	//Asynchronous  mode through RabbitMQ
	@RequestMapping("/exstreampushMQ")
	public String empowerpushMQ() {

		DocumentDCS documentdcs = new DocumentDCS();
		documentdcs = rabbitMQSender.getserviceQueue();
		// System.out.println(documentdcs.concatvalues());
		Document document = new Document(documentdcs.getclaimNumber(), documentdcs.concatvalues());
		RestTemplate restTemplate = new RestTemplate();
		try {
			return restTemplate.postForObject(uri, document, String.class);

		} catch (Exception e) {
			System.out.println(e);
			return e.toString();
		}

	}

	
	@GetMapping("/hello")
	public String test1() {
return "Hello World";
	}


}
