package com.exstreamproxyservice.exstreamproxyservice;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.exstreamproxyservice.exstreamproxyservice.configs.RabbitMQSender;
import com.exstreamproxyservice.exstreamproxyservice.controllers.ExstreamProxyServiceController;
import com.exstreamproxyservice.exstreamproxyservice.models.DocumentDCS;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ExstreamProxyServiceController.class)
public class ExstreamProxyServiceControllerTest {
	@Value("${empowerUri}")
	String uri;
	
	
	@MockBean
	private AmqpTemplate amqpTemplate;
	@MockBean
	RabbitMQSender rabbitMQSender;

	@Autowired
	MockMvc mockMvc;
	
	
	@Test
	public void helloWorld_basic() throws Exception {
	
		RequestBuilder request = MockMvcRequestBuilders
				.get("/hello")
				.accept(MediaType.APPLICATION_JSON);
		
		MvcResult result = mockMvc.perform(request).andReturn();
		
		//verify "Hello World"
		System.out.println(result.getResponse().getStatus());
		assertEquals(200,result.getResponse().getStatus());
	
		//verify "Hello World"
		System.out.println(result.getResponse().getContentAsString());
		assertEquals("Hello World", result.getResponse().getContentAsString());
		//verify "Hello World"
	//	assertEquals("Hello","Hello" );
	}

	
	
	@Test
	public void tesExstreampush() throws Exception {
		DocumentDCS mokeDocumentDCS = new DocumentDCS("312-36-30087","Bob G Smith","1409 Roper Mountain Road","SC","29615","2018-07-06T00:00:00+00:00","WorkersComp","32-300869","08022019","surajprakash.a@hcl.com","MedicareLetter", "Bob G Smith");
		String ExpectResponse = "{\"fileurl\":\"http://13.90.36.249:8085/LetterExpress/312-36-30087_20204827014837.txt\",\"filename\":\"312-36-30087_20204827014837.txt\"}";

				RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/exstreampush").accept(MediaType.APPLICATION_JSON)
				.content(ExpectResponse).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();

		assertEquals(HttpStatus.OK.value(), response.getStatus());
		ObjectMapper Obj = new ObjectMapper();

		String jsonStr = Obj.writeValueAsString(ExpectResponse);
		// Displaying JSON String	
		System.out.println(jsonStr);

		//assertEquals(jsonStr, response.getContentAsString());

		// assertEquals("http://localhost/newemployee",
		// response.getHeader(HttpHeaders.LOCATION));

	}
	
	
	
	@Test
	public void tesExstreampushMQ() throws Exception {
		DocumentDCS mokeDocumentDCS = new DocumentDCS("312-36-30087","Bob G Smith","1409 Roper Mountain Road","SC","29615","2018-07-06T00:00:00+00:00","WorkersComp","32-300869","08022019","surajprakash.a@hcl.com","MedicareLetter", "Bob G Smith");
		String ExpectResponse = "{\"fileurl\":\"http://13.90.36.249:8085/LetterExpress/312-36-30087_20204827014837.txt\",\"filename\":\"312-36-30087_20204827014837.txt\"}";

		// studentService.addCourse to respond back with mockCourse
		Mockito.when(rabbitMQSender.getserviceQueue()).thenReturn(mokeDocumentDCS);		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/exstreampushMQ").accept(MediaType.APPLICATION_JSON)
				.content(ExpectResponse).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();
System.out.println("result.getResponse() "+result.getResponse().getStatus());
		assertEquals(HttpStatus.OK.value(), response.getStatus());
		ObjectMapper Obj = new ObjectMapper();

		String jsonStr = Obj.writeValueAsString(ExpectResponse);
		// Displaying JSON String		
	//	System.out.println("jsonStr "+jsonStr);
	//	System.out.println("response.getContentAsString() "+response.getContentAsString());

	//	assertEquals(jsonStr, response.getContentAsString());

		// assertEquals("http://localhost/newemployee",
		// response.getHeader(HttpHeaders.LOCATION));

	}
		
	
	

	
}
